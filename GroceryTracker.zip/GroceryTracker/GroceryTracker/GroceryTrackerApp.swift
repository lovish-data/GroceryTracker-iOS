import SwiftUI

@main
struct GroceryTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView() // Start with the Tab Bar
        }
    }
}
