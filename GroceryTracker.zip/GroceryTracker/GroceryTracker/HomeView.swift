import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    
                    // Header Section
                    HStack {
                        Text("Grocery tracker")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Spacer()
                        
                        Button(action: {
                            print("Subscribe tapped")
                        }) {
                            Text("Subscribe")
                                .font(.caption)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding(.horizontal)

                    // Budget Card with Wallet Icon
                    VStack(alignment: .leading) {
                        HStack {
                            Image(systemName: "wallet.pass") // Wallet icon
                                .resizable()
                                .scaledToFit()
                                .frame(width: 20, height: 20)
                                .foregroundColor(.green)
                            
                            Text("Grocery budget")
                                .font(.headline)
                        }

                        Text("€39")
                            .font(.title)
                            .fontWeight(.bold)
                        Text("Your monthly budget")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(12)
                    .padding(.horizontal)
                    
                    // Expired Products Section
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Expired products")
                                .font(.headline)
                            Spacer()
                            NavigationLink(destination: ViewAllProductsView()) {
                                Text("View all")
                                    .foregroundColor(.green)
                            }
                        }
                        .padding(.horizontal)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 15) {
                                ForEach(["onion", "tomato", "carrot", "eggs"], id: \.self) { item in
                                    VStack {
                                        Image(item)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 60, height: 60)
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                        Text(item.capitalized)
                                            .font(.caption)
                                    }
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(10)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    // Expiring Soon Section
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Expiring Soon")
                                .font(.headline)
                            Spacer()
                            NavigationLink(destination: ViewAllProductsView()) {
                                Text("View all")
                                    .foregroundColor(.green)
                            }
                        }
                        .padding(.horizontal)
                        
                        VStack {
                            ExpiringProductCard(name: "Onion Bag", expiryDate: "02/05/2024", imageName: "onion_bag")
                            ExpiringProductCard(name: "Tomato Pack", expiryDate: "05/05/2024", imageName: "tomato_pack")
                        }
                    }
                    
                    // Total Family Members
                    VStack {
                        Text("Total Family Members")
                            .font(.headline)
                        HStack {
                            VStack {
                                Text("Adults")
                                Text("2")
                                    .font(.title)
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            
                            VStack {
                                Text("Children")
                                Text("1")
                                    .font(.title)
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .navigationTitle("Home")
        }
    }
}

// Expiring Product Card Component
struct ExpiringProductCard: View {
    var name: String
    var expiryDate: String
    var imageName: String // New parameter for the image
    
    var body: some View {
        HStack {
            Image(imageName) // Displaying product image
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .cornerRadius(8)

            VStack(alignment: .leading) {
                Text(name)
                    .font(.headline)
                Text("Expiry date: \(expiryDate)")
                    .font(.caption)
                    .foregroundColor(.gray)
                
                Button(action: {
                    print("View details tapped")
                }) {
                    Text("View details")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }
            .padding(.leading, 10)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
}
