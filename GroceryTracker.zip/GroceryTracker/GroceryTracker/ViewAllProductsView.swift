import SwiftUI

struct ViewAllProductsView: View {
    let allProducts = [
        ("Onion", "onion"),
        ("Tomato", "tomato"),
        ("Carrot", "carrot"),
        ("Potato", "potato"),
        ("Eggs", "eggs"),
        ("Cabbage", "cabbage")
    ]
    
    var body: some View {
        VStack {
            Text("All Expired Products")
                .font(.title)
                .fontWeight(.bold)
                .padding(.top)
            
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(allProducts, id: \.0) { product in
                        VStack {
                            Image(product.1) // Image from Assets.xcassets
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80, height: 80)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            
                            Text(product.0)
                                .font(.headline)
                                .foregroundColor(.black)
                        }
                        .padding()
                        .frame(width: 120, height: 140)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                    }
                }
                .padding()
            }
        }
        .navigationTitle("View All")
    }
}
