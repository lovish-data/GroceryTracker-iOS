//
//  GroceryTrackerTests.swift
//  GroceryTrackerTests
//
//  Created by Lovish Gupta on 02/04/25.
//

import Testing
@testable import GroceryTracker

struct GroceryTrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
